oex export
==========

Generated:        2026-08-07 00:27:21 UTC
oex version:      0.4.7
Project:          https://github.com/osgeonepal/oex

Country (ISO3):   YEM
Boundary:         geoBoundaries CGAZ ADM0
Bounding box:     (41.8154, 12.1081, 54.5342, 19.0000)

Dataset:          education_facilities
Format:           GeoJSON (geojson)
Features:         1,767

Source:           OpenStreetMap contributors
Source URL:       https://www.openstreetmap.org/
Snapshot:         2026-08-07
License:          hdx-odc-odbl
License URL:      https://opendatacommons.org/licenses/odbl/1-0/

About the source
  OpenStreetMap is a community-edited geographic dataset of the world. Country
  features are extracted from the source PBF via quackosm with the union of
  all category tag filters; per-category exports apply tag predicates at query
  time.

Notes
  - GeoJSON is a single-file text format. Consider gpkg for very large layers.

Feedback:         https://github.com/osgeonepal/oex/issues
Engine: geofabrik